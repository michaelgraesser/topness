#include<stdio.h> 
#include<stdlib.h>
#include<iostream>
#include<cmath>
#include<algorithm> 
#include <cstdlib> 
#include <ctime>

#include "source/topness/Wrappertopness.h"

/* written by Michael L. Graesser 

   does minimization algorithm from Nelder and Mead 


   Nelder, John A.; R. Mead (1965). 
   "A simplex method for function minimization". 
   Computer Journal 7: 308–313. doi:10.1093/comjnl/7.4.308.  

   Algorithm from their Fig. 1 

   returns S, topness is given by ln S 

   custom source code for Nelder-Mead routine found in source/my_Nelder-Mead/ 

If using topness, please cite 

Hunting Mixed Top Squark Decays 
Michael L. Graesser, Jessie Shelton
Phys.Rev.Lett. 111 (2013) 12, 121802 
DOI: 10.1103/PhysRevLett.111.121802 
arXiv:1212.4495


top and W masses used in the topness algorithm set in header file source/topness/topness_struc.h 

*/

int main(){ 

  // fake dilep point 1
 
  double pb1[]={189.771214, 147.908732, 200.159747, 313.501729};
  double pb2[]={-104.706722, -5.979827, 332.725106, 349.056386}; 
  double pl[]={-352.278722, -144.392071, 678.281844, 777.82750};
  double MET[]={274.592057, 116.336272, 0.000000, 0.000000};
  // min is 1.47
  
  // fake dilep point 2 
  /*
  double pb1[]={-21.885289, 64.292449, -102.161254, 122.945578}; 
  double pb2[]={-49.902055, -20.671257, 10.128161, 56.032096}; 
  double pl[]={162.525060, 135.998859, -206.947388, 296.204857}; 
  double MET[]={-104.778921, -246.481543, 0.000000, 0.000000}; 
  */ 
  // min is 0.09
  

  int d=4; 
  
  // scale parameters for topness function 
  
  double sigmat=15.;
  double sigmaW=5.; 
  double sigmas=1000;
   
  
  // xbest is the initial guess for unknown kinematic variables pvx, pvy, pyz (neutrino momentum) and pWz (missing W's pz) that minimizes the topness function 
  // xbest=[pvx, pvy, pvz, pWz]
  double xbest[]={1000.,1000.,1000.,1000.};

  // value at lowest minimum, topness is ln (ybest)  
  double ybest; 

  /* Now perform topness computation. 
     the following call to topnesscompute performs the minimization and evalutes both combinations 
     pb1 with pl, and pb2 with pl. 

     topnesscompute is declared in source/topness/Wrappertopness.h and defined in source/topness/Wrappertopness.cpp

     The number of attempts to find the global minimum, started with a different random seed, is given 
     by the variable Nattempts, declared and defined in topnesscompute.  
     currently the number of attempts is set to 15. 

     The routine topnesscompute makes use of the side effect that in c++ an array - here xbest -  is passed to a function by a pointer, 
     so the array can be modified by the function it is passed to; that is, it is passed by reference 
  */

  // all the work is done here
  ybest=topnesscompute(pb1, pb2, pl, MET, sigmat, sigmaW, sigmas, xbest); 
        
  cout << " The best minimum is " << ybest << endl; 
  cout << " located at..." << endl; 
  for (int i=0; i < d; i++)
    {
       cout << xbest[i] ;
       if ((i+1) % d == 0)
       {
	 cout << endl;
       }
       else
       {
	 cout << ", " ;
       }
    }

  int t=clock();
  cout << "It took the program " << t << " clicks, or " << ((float) t)/CLOCKS_PER_SEC << " seconds." << endl; 
  return 0; 

}
